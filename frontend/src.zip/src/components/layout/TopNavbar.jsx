import "../../styles/layout.css";

const TopNavbar = () => {

    return (

        <header className="topbar">

            <div>

                <h1>Security Operations Dashboard</h1>

                <p>
                    AI-powered DDoS Detection & Monitoring
                </p>

            </div>

            <div className="user-box">

                <div className="status-dot"></div>

                <span>Admin</span>

            </div>

        </header>

    );

};

export default TopNavbar;