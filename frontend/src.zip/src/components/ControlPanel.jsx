import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import {
    FaPlay,
    FaStop,
    FaNetworkWired
} from "react-icons/fa";

const API = "http://localhost:5001/api";

export default function ControlPanel() {

    const [running, setRunning] = useState(false);

    useEffect(() => {

        async function loadState() {

            try {

                const res = await fetch(`${API}/system-health`);

                if (!res.ok) return;

                const data = await res.json();

                setRunning(data.simulation_running);

            }

            catch {}

        }

        loadState();

    }, []);

    async function startSimulation() {

        try {

            const token = localStorage.getItem("token");

            const res = await fetch(`${API}/simulate/start`, {

                method: "POST",

                headers: {

                    "Content-Type": "application/json",

                    Authorization: `Bearer ${token}`

                },

                body: JSON.stringify({

                    attack_type: "random"

                })

            });

            const data = await res.json();

            if (!res.ok)
                throw new Error(data.error);

            toast.success("Live traffic simulation started");

            setRunning(true);

        }

        catch (err) {

            toast.error(err.message);

        }

    }

    async function stopSimulation() {

        try {

            const token = localStorage.getItem("token");

            console.log("STOP BUTTON CLICKED");

            const res = await fetch(`${API}/simulate/stop`, {

                method: "POST",

                headers: {

                    Authorization: `Bearer ${token}`

                }

            });

            const data = await res.json();

            console.log(data);

            if (!res.ok)
                throw new Error(data.error);

            toast.success("Simulation stopped");

            setRunning(false);

        }

        catch (err) {

            console.log(err);

            toast.error(err.message);

        }

    }

    return (

        <div className="control-panel">

            <h3>

                <FaNetworkWired />

                &nbsp; Live Traffic Simulator

            </h3>

            <button

                className="sim-btn syn"

                disabled={running}

                onClick={startSimulation}

            >

                <FaPlay />

                Start Live Traffic

            </button>

            <button

                className="sim-btn stop"

                onClick={stopSimulation}

            >

                <FaStop />

                Stop Simulation

            </button>

            <div className="status-box">

                Status :

                <strong>

                    {running ? " Running" : " Stopped"}

                </strong>

            </div>

            <p
                style={{
                    marginTop: "14px",
                    opacity: 0.75,
                    fontSize: "13px",
                    lineHeight: "1.6"
                }}
            >
                The simulator automatically generates a realistic mixture of
                normal network traffic and DDoS attacks. Alerts are raised only
                when malicious traffic is detected.
            </p>

        </div>

    );

}