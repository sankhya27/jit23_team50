import { motion } from "framer-motion";
import "../../styles/dashboard.css";

const KPICard = ({ title, value, icon, color, subtitle }) => {
  return (
    <motion.div
      className="kpi-card"
      whileHover={{
        y: -6,
        scale: 1.02
      }}
      transition={{ duration: 0.2 }}
    >
      <div className="kpi-header">

        <div>

          <h4>{title}</h4>

          <small>{subtitle}</small>

        </div>

        <div
          className="icon-circle"
          style={{
            background: color
          }}
        >
          {icon}
        </div>

      </div>

      <h2>{value}</h2>

    </motion.div>
  );
};

export default KPICard;