import { useEffect, useState } from "react";

const countries = [
    "India",
    "USA",
    "Germany",
    "Russia",
    "China",
    "Japan",
    "Brazil",
    "Canada"
];

export default function AttackOrigins({ attacks }) {

    const [list,setList]=useState([]);

    useEffect(()=>{

        const arr=[];

        for(let i=0;i<5;i++){

            arr.push({

                country:countries[i],

                count:Math.floor(Math.random()*40)+5

            });

        }

        setList(arr);

    },[attacks]);

    return(

        <div className="chart-card">

            <h3>

                🌍 Attack Origins

            </h3>

            {

                list.map((item,index)=>(

                    <div
                        className="country-row"
                        key={index}
                    >

                        <div>

                            {item.country}

                        </div>

                        <div
                            className="country-bar"
                        >

                            <div
                                className="country-fill"
                                style={{

                                    width:`${item.count*2}%`

                                }}
                            />

                        </div>

                        <strong>

                            {item.count}

                        </strong>

                    </div>

                ))

            }

        </div>

    );

}