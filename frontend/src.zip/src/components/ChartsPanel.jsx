import { useEffect, useState } from "react";

import {
    AreaChart,
    Area,
    ResponsiveContainer,
    Tooltip,
    XAxis,
    YAxis,
    CartesianGrid,
    Legend
} from "recharts";

export default function ChartsPanel({ metrics }) {

    const [history, setHistory] = useState([]);

    useEffect(() => {

        const point = {

            time: new Date().toLocaleTimeString([], {

                hour: "2-digit",

                minute: "2-digit",

                second: "2-digit"

            }),

            normal: metrics.live_normal || 0,

            attack: metrics.live_attack || 0

        };

        setHistory(prev => {

            const updated = [...prev, point];

            if (updated.length > 30)

                updated.shift();

            return updated;

        });

    }, [

        metrics.live_normal,

        metrics.live_attack

    ]);

    return (

        <div

            className="chart-card"

            id="live-network-chart"

        >

            <h3>

                Live Network Traffic

            </h3>

            <ResponsiveContainer

                width="100%"

                height={300}

            >

                <AreaChart data={history}>

                    <defs>

                        <linearGradient

                            id="normalTraffic"

                            x1="0"

                            y1="0"

                            x2="0"

                            y2="1"

                        >

                            <stop

                                offset="5%"

                                stopColor="#3ddc84"

                                stopOpacity={0.9}

                            />

                            <stop

                                offset="95%"

                                stopColor="#3ddc84"

                                stopOpacity={0.05}

                            />

                        </linearGradient>

                        <linearGradient

                            id="attackTraffic"

                            x1="0"

                            y1="0"

                            x2="0"

                            y2="1"

                        >

                            <stop

                                offset="5%"

                                stopColor="#ff4d4d"

                                stopOpacity={0.9}

                            />

                            <stop

                                offset="95%"

                                stopColor="#ff4d4d"

                                stopOpacity={0.05}

                            />

                        </linearGradient>

                    </defs>

                    <CartesianGrid

                        stroke="rgba(255,255,255,.08)"

                    />

                    <XAxis

                        dataKey="time"

                        stroke="#9fb4d9"

                    />

                    <YAxis

                        allowDecimals={false}

                        stroke="#9fb4d9"

                    />

                    <Tooltip />

                    <Legend />

                    <Area

                        type="monotone"

                        dataKey="normal"

                        name="Normal Traffic"

                        stroke="#3ddc84"

                        fill="url(#normalTraffic)"

                    />

                    <Area

                        type="monotone"

                        dataKey="attack"

                        name="Attack Traffic"

                        stroke="#ff4d4d"

                        fill="url(#attackTraffic)"

                    />

                </AreaChart>

            </ResponsiveContainer>

        </div>

    );

}