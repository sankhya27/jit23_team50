import { useEffect, useState } from "react";
import { FaBug, FaCheckCircle } from "react-icons/fa";

const API = "http://localhost:5001/api";

export default function RecentAlerts() {

    const [alerts, setAlerts] = useState([]);

    useEffect(() => {

        loadAlerts();

        const timer = setInterval(loadAlerts, 2000);

        return () => clearInterval(timer);

    }, []);

    async function loadAlerts() {

        try {

            const token = localStorage.getItem("token");

            const res = await fetch(`${API}/incidents`, {

                headers: {

                    Authorization: `Bearer ${token}`

                }

            });

            if (!res.ok)
                return;

            const data = await res.json();

            if (Array.isArray(data)) {

                setAlerts(data.slice(0,5));

            }

            else {

                setAlerts([]);

            }

        }

        catch(err){

            console.log(err);

        }

    }

    return(

        <div className="chart-card">

            <h3>Recent Alerts</h3>

            {

                alerts.length===0 ?

                <p className="no-alerts">

                    <FaCheckCircle/>

                    No attacks detected.

                </p>

                :

                alerts.map(alert=>(

                    <div
                        key={alert._id}
                        className="alert-item"
                    >

                        <div>

                            <FaBug color="#ff5b5b"/>

                        </div>

                        <div className="alert-content">

                            <strong>

                                {alert.attackType}

                            </strong>

                            <span>

                                {alert.severity.toUpperCase()} • {" "}

                                {Math.round(
                                    (alert.detection?.confidence || 0)*100
                                )}%

                            </span>

                        </div>

                    </div>

                ))

            }

        </div>

    );

}