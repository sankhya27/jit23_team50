import { useEffect, useState } from "react";
import RecentAlerts from "../components/RecentAlerts";
import MainLayout from "../components/layout/MainLayout";
import KPICard from "../components/dashboard/KPICard";
import ChartsPanel from "../components/ChartsPanel";
import ControlPanel from "../components/ControlPanel";

import { getMetrics } from "../api";

import {
    FaShieldAlt,
    FaBug,
    FaBan,
    FaClock,
    FaServer,
    FaChartLine
} from "react-icons/fa";

import "../styles/dashboard.css";

const API = "http://localhost:5001/api";

function authHeader() {

    const token = localStorage.getItem("token");

    return {
        Authorization: `Bearer ${token}`
    };

}

const Dashboard = () => {

    const [metrics, setMetrics] = useState({

        packets_sent: 0,
        attacks_detected: 0,
        packets_blocked: 0,
        avg_latency_ms: 0,
        effectiveness_pct: 100,
        uptime_seconds: 0

    });

    const [analytics, setAnalytics] = useState({

        attackTypes: {},
        severity: {}

    });

    useEffect(() => {

        loadMetrics();
        loadAnalytics();

        const eventSource = new EventSource(
            "http://localhost:5001/api/simulate/stream"
        );

        eventSource.onmessage = (event) => {

            const data = JSON.parse(event.data);

            if (data.metrics) {

                setMetrics(data.metrics);

            }

        };

        eventSource.onerror = () => {

            console.log("SSE disconnected");

        };

        return () => {

            eventSource.close();

        };

    }, []);

    async function loadMetrics() {

        try {

            const data = await getMetrics();

            setMetrics(data);

        }

        catch (err) {

            console.log(err);

        }

    }

    async function loadAnalytics() {

        try {

            const res = await fetch(

                `${API}/analytics`,

                {

                    headers: authHeader()

                }

            );

            const data = await res.json();

            setAnalytics(data);

        }

        catch (err) {

            console.log(err);

        }

    }

    return (

        <MainLayout>

            <div className="dashboard-wrapper">

                <div className="kpi-grid">

                    <KPICard
                        title="Packets Analysed"
                        subtitle="Total Traffic"
                        value={metrics.packets_sent}
                        color="#2ea8ff"
                        icon={<FaServer />}
                    />

                    <KPICard
                        title="Attacks Detected"
                        subtitle="Threats Found"
                        value={metrics.attacks_detected}
                        color="#ff5b5b"
                        icon={<FaBug />}
                    />

                    <KPICard
                        title="Packets Blocked"
                        subtitle="Firewall"
                        value={metrics.packets_blocked}
                        color="#ffae42"
                        icon={<FaBan />}
                    />

                    <KPICard
                        title="Detection Time"
                        subtitle="Average"
                        value={`${metrics.avg_latency_ms} ms`}
                        color="#00bcd4"
                        icon={<FaClock />}
                    />

                    <KPICard
                        title="Detection Accuracy"
                        subtitle="Effectiveness"
                        value={`${metrics.effectiveness_pct}%`}
                        color="#2ecc71"
                        icon={<FaShieldAlt />}
                    />

                    <KPICard
                        title="System Uptime"
                        subtitle="Backend"
                        value={`${metrics.uptime_seconds}s`}
                        color="#8b5cf6"
                        icon={<FaChartLine />}
                    />

                </div>

                <div className="dashboard-bottom">

                    <div className="left-column">

                        <ChartsPanel
                            metrics={metrics}
                            analytics={analytics}
                        />

                        <ControlPanel />

                    </div>

                    <div className="right-column">

                        <RecentAlerts />

                    </div>

                </div>

            </div>

        </MainLayout>

    );

};

export default Dashboard;