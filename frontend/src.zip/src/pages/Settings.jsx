import { useEffect, useState } from "react";

import MainLayout from "../components/layout/MainLayout";

import "../styles/settings.css";

const API = "http://localhost:5001/api";

function authHeader() {

    const token = localStorage.getItem("token");

    return {

        Authorization: `Bearer ${token}`,

        "Content-Type": "application/json"

    };

}

export default function Settings() {

    const [email, setEmail] = useState("");

    const [enabled, setEnabled] = useState(true);

    const [message, setMessage] = useState("");

    async function loadSettings() {

        const res = await fetch(

            `${API}/alert-preferences`,

            {

                headers: authHeader()

            }

        );

        const data = await res.json();

        if (data.preferences) {

            setEmail(data.preferences.email || "");

            setEnabled(data.preferences.enabled);

        }

    }

    useEffect(() => {

        loadSettings();

    }, []);

    async function saveSettings() {

        await fetch(

            `${API}/alert-preferences`,

            {

                method: "POST",

                headers: authHeader(),

                body: JSON.stringify({

                    email,

                    enabled

                })

            }

        );

        setMessage("Settings Saved Successfully");

        setTimeout(() => {

            setMessage("");

        }, 3000);

    }

    async function sendTestAlert() {

        const res = await fetch(

            `${API}/alert-preferences/test`,

            {

                method: "POST",

                headers: authHeader()

            }

        );

        const data = await res.json();

        alert(data.message);

    }

    return (

        <MainLayout>

            <div className="settings-page">

                <h1>

                    Email Alert Settings

                </h1>

                <div className="settings-card">

                    <label>

                        Email Address

                    </label>

                    <input

                        value={email}

                        placeholder="Enter email address"

                        onChange={(e)=>

                            setEmail(e.target.value)

                        }

                    />

                    <div className="switch-row">

                        <label>

                            Enable Email Alerts

                        </label>

                        <input

                            type="checkbox"

                            checked={enabled}

                            onChange={(e)=>

                                setEnabled(e.target.checked)

                            }

                        />

                    </div>

                    <div className="button-row">

                        <button

                            className="save-btn"

                            onClick={saveSettings}

                        >

                            Save Settings

                        </button>

                        <button

                            className="test-btn"

                            onClick={sendTestAlert}

                        >

                            Send Test Alert

                        </button>

                    </div>

                    {

                        message &&

                        <p className="success">

                            {message}

                        </p>

                    }

                </div>

            </div>

        </MainLayout>

    );

}