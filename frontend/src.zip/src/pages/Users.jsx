
import { useEffect, useState } from "react";

import MainLayout from "../components/layout/MainLayout";

import {

    getUsers,
    updateUserRole,
    deleteUser

} from "../api";

import "../styles/users.css";

export default function Users() {

    const [users, setUsers] = useState([]);

    const [search, setSearch] = useState("");

    async function loadUsers() {

        try {

            const data = await getUsers();

            setUsers(data.users || []);

        }

        catch (err) {

            console.log(err);

        }

    }

    useEffect(() => {

        loadUsers();

    }, []);

    async function changeRole(id, currentRole) {

        const newRole =

            currentRole === "admin"

                ? "analyst"

                : "admin";

        const result = await updateUserRole(id, newRole);

        if (result.status === "success") {

            loadUsers();

        }

        else {

            alert(result.error);

        }

    }

    async function removeUser(id) {

        const ok = window.confirm(

            "Delete this user?"

        );

        if (!ok) return;

        const result = await deleteUser(id);

        if (result.status === "success") {

            loadUsers();

        }

        else {

            alert(result.error);

        }

    }

    const filtered = users.filter(user =>

        user.username.toLowerCase().includes(search.toLowerCase()) ||

        user.email.toLowerCase().includes(search.toLowerCase())

    );

    const admins = users.filter(

        x => x.role === "admin"

    ).length;

    const analysts = users.filter(

        x => x.role === "analyst"

    ).length;

    return (

        <MainLayout>

            <div className="users-page">

                <div className="users-header">

                    <h1>

                        Users Management

                    </h1>

                    <input

                        placeholder="Search users..."

                        value={search}

                        onChange={(e)=>

                            setSearch(e.target.value)

                        }

                    />

                </div>

                <div className="users-summary">

                    <div className="summary-card">

                        <h2>

                            {users.length}

                        </h2>

                        <p>Total Users</p>

                    </div>

                    <div className="summary-card">

                        <h2>

                            {admins}

                        </h2>

                        <p>Admins</p>

                    </div>

                    <div className="summary-card">

                        <h2>

                            {analysts}

                        </h2>

                        <p>Analysts</p>

                    </div>

                </div>

                <table className="users-table">

                    <thead>

                        <tr>

                            <th>Username</th>

                            <th>Email</th>

                            <th>Role</th>

                            <th>Created</th>

                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                        {

                            filtered.map(user => (

                                <tr

                                    key={user._id}

                                >

                                    <td>

                                        {user.username}

                                    </td>

                                    <td>

                                        {user.email}

                                    </td>

                                    <td>

                                        <span

                                            className={`role ${user.role}`}

                                        >

                                            {

                                                user.role

                                            }

                                        </span>

                                    </td>

                                    <td>

                                        {

                                            new Date(user.createdAt)

                                            .toLocaleDateString()

                                        }

                                    </td>

                                    <td>

                                        <button

                                            className="edit-btn"

                                            onClick={()=>

                                                changeRole(

                                                    user._id,

                                                    user.role

                                                )

                                            }

                                        >

                                            Change Role

                                        </button>

                                        <button

                                            className="delete-btn"

                                            onClick={()=>

                                                removeUser(user._id)

                                            }

                                        >

                                            Delete

                                        </button>

                                    </td>

                                </tr>

                            ))

                        }

                    </tbody>

                </table>

            </div>

        </MainLayout>

    );

}