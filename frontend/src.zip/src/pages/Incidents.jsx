
import { useEffect, useState } from "react";

import MainLayout from "../components/layout/MainLayout";

import "../styles/incidents.css";

const API = "http://localhost:5001/api";

export default function Incidents() {

    const [incidents, setIncidents] = useState([]);

    const [loading, setLoading] = useState(true);

    useEffect(() => {

        loadIncidents();

        const timer = setInterval(loadIncidents, 3000);

        return () => clearInterval(timer);

    }, []);

    async function loadIncidents() {

        try {

            const token = localStorage.getItem("token");

            const res = await fetch(`${API}/incidents`, {

                headers: {

                    Authorization: `Bearer ${token}`

                }

            });

            const data = await res.json();

            if (Array.isArray(data.incidents)) {

                setIncidents(data.incidents);

            }

            else {

                setIncidents([]);

            }

        }

        catch (err) {

            console.log(err);

            setIncidents([]);

        }

        finally {

            setLoading(false);

        }

    }

    return (

        <MainLayout>

            <div className="incidents-page">

                <h1>

                    Security Incidents

                </h1>

                {

                    loading ?

                        <p>Loading incidents...</p>

                        :

                        incidents.length === 0 ?

                            <p>No incidents found.</p>

                            :

                            <table className="incident-table">

                                <thead>

                                    <tr>

                                        <th>Attack</th>

                                        <th>Severity</th>

                                        <th>Source IP</th>

                                        <th>Confidence</th>

                                        <th>Status</th>

                                        <th>Time</th>

                                    </tr>

                                </thead>

                                <tbody>

                                    {

                                        incidents.map((item) => (

                                            <tr key={item._id}>

                                                <td>

                                                    {item.attackType}

                                                </td>

                                                <td>

                                                    <span className={`severity ${item.severity}`}>

                                                        {item.severity}

                                                    </span>

                                                </td>

                                                <td>

                                                    {item.sourceIP}

                                                </td>

                                                <td>

                                                    {

                                                        Math.round(

                                                            (item.detection?.confidence || 0) * 100

                                                        )

                                                    }%

                                                </td>

                                                <td>

                                                    {

                                                        item.mitigation?.ipBlocked

                                                            ? "Blocked"

                                                            : "Detected"

                                                    }

                                                </td>

                                                <td>

                                                    {

                                                        new Date(item.createdAt)

                                                            .toLocaleString()

                                                    }

                                                </td>

                                            </tr>

                                        ))

                                    }

                                </tbody>

                            </table>

                }

            </div>

        </MainLayout>

    );

}
