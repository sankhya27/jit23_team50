import { useEffect, useState } from "react";

import {
    PieChart,
    Pie,
    Cell,
    Tooltip,
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid
} from "recharts";

import MainLayout from "../components/layout/MainLayout";

import "../styles/analytics.css";

const API = "http://localhost:5001/api";

const COLORS = [
    "#0088FE",
    "#00C49F",
    "#FFBB28",
    "#FF8042",
    "#AA66CC"
];

function authHeader() {

    const token = localStorage.getItem("token");

    return {

        Authorization: `Bearer ${token}`

    };

}

export default function Analytics() {

    const [analytics, setAnalytics] = useState(null);

    useEffect(() => {

        loadAnalytics();

    }, []);

    async function loadAnalytics() {

        const res = await fetch(

            `${API}/analytics`,

            {

                headers: authHeader()

            }

        );

        const data = await res.json();

        setAnalytics(data);

    }

    if (!analytics) {

        return (

            <MainLayout>

                <div className="analytics-page">

                    Loading Analytics...

                </div>

            </MainLayout>

        );

    }

    const attackData = Object.entries(

        analytics.attackTypes || {}

    ).map(

        ([name, value]) => ({

            name,

            value

        })

    );

    const severityData = Object.entries(

        analytics.severity || {}

    ).map(

        ([name, value]) => ({

            name,

            value

        })

    );

    return (

        <MainLayout>

            <div className="analytics-page">

                <h1>

                    Security Analytics

                </h1>

                <div className="analytics-cards">

                    <div className="analytics-card">

                        <h3>Total Incidents</h3>

                        <h2>

                            {analytics.totalIncidents}

                        </h2>

                    </div>

                    <div className="analytics-card">

                        <h3>

                            Avg Detection Latency

                        </h3>

                        <h2>

                            {analytics.averageLatency} ms

                        </h2>

                    </div>

                    <div className="analytics-card">

                        <h3>

                            Detection Effectiveness

                        </h3>

                        <h2>

                            {analytics.averageEffectiveness}%

                        </h2>

                    </div>

                </div>

                <div className="chart-grid">

                    <div className="chart-card">

                        <h3>

                            Attack Types

                        </h3>

                        <ResponsiveContainer
                            width="100%"
                            height={300}
                        >

                            <BarChart data={attackData}>

                                <CartesianGrid strokeDasharray="3 3"/>

                                <XAxis dataKey="name"/>

                                <YAxis/>

                                <Tooltip/>

                                <Bar
                                    dataKey="value"
                                    fill="#4CAF50"
                                />

                            </BarChart>

                        </ResponsiveContainer>

                    </div>

                    <div className="chart-card">

                        <h3>

                            Severity Distribution

                        </h3>

                        <ResponsiveContainer
                            width="100%"
                            height={300}
                        >

                            <PieChart>

                                <Pie

                                    data={severityData}

                                    dataKey="value"

                                    nameKey="name"

                                    outerRadius={100}

                                >

                                    {

                                        severityData.map(

                                            (entry,index)=>(

                                                <Cell

                                                    key={index}

                                                    fill={COLORS[index%COLORS.length]}

                                                />

                                            )

                                        )

                                    }

                                </Pie>

                                <Tooltip/>

                            </PieChart>

                        </ResponsiveContainer>

                    </div>

                </div>

                <div className="table-card">

                    <h2>

                        Top Attacking IPs

                    </h2>

                    <table>

                        <thead>

                            <tr>

                                <th>IP Address</th>

                                <th>Attacks</th>

                            </tr>

                        </thead>

                        <tbody>

                            {

                                analytics.topAttackers.map(

                                    (

                                        attacker,

                                        index

                                    )=>(

                                        <tr key={index}>

                                            <td>

                                                {attacker[0]}

                                            </td>

                                            <td>

                                                {attacker[1]}

                                            </td>

                                        </tr>

                                    )

                                )

                            }

                        </tbody>

                    </table>

                </div>

            </div>

        </MainLayout>

    );

}