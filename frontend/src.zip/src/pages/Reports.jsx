import { useEffect, useState } from "react";
import generatePDF from "../report/pdfGenerator";
import MainLayout from "../components/layout/MainLayout";

import "../styles/reports.css";

const API = "http://localhost:5001/api";

function authHeader() {
    const token = localStorage.getItem("token");

    return {
        Authorization: `Bearer ${token}`
    };
}

export default function Reports() {

    const [analytics, setAnalytics] = useState(null);

    const [incidents, setIncidents] = useState([]);

    const [lastGenerated, setLastGenerated] = useState("-");

    useEffect(() => {

        loadData();

    }, []);

    async function loadData() {

        try {

            //------------------------------------------------
            // Analytics
            //------------------------------------------------

            const analyticsRes = await fetch(

                `${API}/analytics`,

                {
                    headers: authHeader()
                }

            );

            const analyticsData = await analyticsRes.json();

            setAnalytics(analyticsData);

            //------------------------------------------------
            // Incidents
            //------------------------------------------------

            const incidentRes = await fetch(

                `${API}/incidents`,

                {
                    headers: authHeader()
                }

            );

            const incidentData = await incidentRes.json();

            setIncidents(

                incidentData.incidents || []

            );

        }

        catch (err) {

            console.log(err);

        }

    }

    async function generateReport() {

        await generatePDF(

            analytics,

            incidents

        );

        setLastGenerated(

            new Date().toLocaleString()

        );

    }

    if (!analytics) {

        return (

            <MainLayout>

                <div className="reports-page">

                    Loading...

                </div>

            </MainLayout>

        );

    }

    return (

        <MainLayout>

            <div className="reports-page">

                <h1>

                    Security Reports

                </h1>

                <div className="report-summary">

                    <div className="report-card">

                        <h3>Total Incidents</h3>

                        <h2>{analytics.totalIncidents}</h2>

                    </div>

                    <div className="report-card">

                        <h3>

                            Average Detection Latency

                        </h3>

                        <h2>

                            {analytics.averageLatency} ms

                        </h2>

                    </div>

                    <div className="report-card">

                        <h3>

                            Detection Effectiveness

                        </h3>

                        <h2>

                            {analytics.averageEffectiveness}%

                        </h2>

                    </div>

                </div>

                <div className="generate-section">

                    <h2>

                        Generate Security Report

                    </h2>

                    <p>

                        Export the complete security analytics as a professional PDF.

                    </p>

                    <button

                        className="generate-btn"

                        onClick={generateReport}

                    >

                        Generate PDF Report

                    </button>

                </div>

                <div className="recent-section">

                    <h2>

                        Recent Reports

                    </h2>

                    <ul>

                        <li>

                            Incident Report

                        </li>

                        <li>

                            Weekly Security Report

                        </li>

                        <li>

                            Monthly Analytics Report

                        </li>

                    </ul>

                    <p>

                        <strong>

                            Last Generated :

                        </strong>{" "}

                        {lastGenerated}

                    </p>

                </div>

            </div>

        </MainLayout>

    );

}